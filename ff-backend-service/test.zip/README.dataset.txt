# Cats and Dogs > 2022-12-22 5:00pm
https://universe.roboflow.com/flockfyshsamples/cats-and-dogs-6j7ld

Provided by a Roboflow user
License: CC BY 4.0

